// 1. Create a function that will return children, teenagers, young people, old people from the age

/*
let name = prompt("Enter Your Name: ");
let age = prompt("Enter Your Age: ");
agePireod(name, age);
*/

// 2. Create a function that will return the area of a rectangle, square, triangle
/**
 * Rectangle Area Cal
 */

// let areaLength=parseInt(prompt('Inter your area length: '));
// let areaWidth=parseInt(prompt('Inter your area width: '));
// rectArea(areaLength,areaWidth)

/**
 * Square Area Cal
 */
/*
let areaSide=parseInt(prompt('Inter your area side: '));
sqrArea(areaSide)
*/

/**
 * Triangle Area Cal
 */

// let areaBase=parseInt(prompt('Inter your area length: '));
// let areaHeight=parseInt(prompt('Inter your area width: '));
// triArea(areaBase, areaHeight)

// 3. GPA, GRADE function for result publishing

//     let sName = prompt('Enter your name: ');
//     let roll = prompt(`Hi, ${sName} enter your roll: `);
//     let cls = prompt(`Hi, ${sName} enter your class: `);

//     let eng = prompt(`Hi, ${sName} enter your english marks: `);
//     let ban = prompt(`Hi, ${sName} enter your bangla marks: `);
//     let math = prompt(`Hi, ${sName} enter your math marks: `);
//     let phy = prompt(`Hi, ${sName} enter your physics marks: `);
//     let che = prompt(`Hi, ${sName} enter your chemistry marks: `);
//     let bio = prompt(`Hi, ${sName} enter your biology marks: `);
//     let ict = prompt(`Hi, ${sName} enter your ICT marks: `);
//     let rel = prompt(`Hi, ${sName} enter your religion marks: `);
// console.log(`

//     Name    : ${sName}
//     Roll    : ${roll}
//     Class   : ${cls}
//     =================================================
//     Subject     Marks       GPA     Grade
//     English     ${eng}        ${getGpa(eng)}      ${getGrade(eng)}
//     Bangla      ${ban}        ${getGpa(ban)}      ${getGrade(ban)}
//     Math        ${math}       ${getGpa(math)}     ${getGrade(math)}
//     Physics     ${phy}        ${getGpa(phy)}      ${getGrade(phy)}
//     Chemistry   ${che}        ${getGpa(che)}      ${getGrade(che)}
//     Biology     ${bio}        ${getGpa(bio)}      ${getGrade(bio)}
//     ICT         ${ict}        ${getGpa(ict)}      ${getGrade(ict)}
//     Religion    ${rel}        ${getGpa(rel)}      ${getGrade(rel)}

// `);

// 4. Create an age calculator function

// let uName = prompt(`Hi! enter your name:`);
// let age = parseFloat(prompt(`Hi ${uName}, enter your birth year:`));
// ageCal(age)

// 5. Create a BMI function for health

/*
let uName = prompt(`Hi, enter your name:`);
let uWeight = parseFloat(prompt(`Hi ${uName}, enter your weight in kg:`));
let uHeight = parseFloat(prompt(`Hi ${uName}, enter your height in inch:`));

let mHeight = uHeight * 0.0254;
let uBmi = uWeight / Math.pow(mHeight, 2);

getBMI(uBmi);
*/

// 6. Create a currency converter function from taka to USD, CAD, POUND, EURO etc

/*
let amount = parseFloat(prompt("Enter your ammount:"));
let currencyName = prompt("Enter your currency name in small later:");

currencyConvert(amount, currencyName);
*/
